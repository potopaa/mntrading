# features/spread.py
# All comments are in English by request.

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm


@dataclass
class SpreadConfig:
    beta_window: int = 300
    z_window: int = 300


def _ensure_schema(raw_df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize raw df schema to the expected columns:
    - 'ts' (datetime64[ns, UTC] or datetime64[ns])
    - 'symbol' (str)
    - 'close' (float)
    The function tries to map common alternative column names.
    """
    df = raw_df.copy()

    # Map timestamp column names
    for cand in ["ts", "timestamp", "time", "date", "datetime"]:
        if cand in df.columns:
            if cand != "ts":
                df = df.rename(columns={cand: "ts"})
            break
    else:
        raise ValueError("Raw dataframe must contain a time column (ts/timestamp/time/date/datetime).")

    # Map close column names
    for cand in ["close", "Close", "CLOSE", "c"]:
        if cand in df.columns:
            if cand != "close":
                df = df.rename(columns={cand: "close"})
            break
    else:
        raise ValueError("Raw dataframe must contain a close column (close/Close/c).")

    # Map symbol column names
    for cand in ["symbol", "ticker", "pair", "asset"]:
        if cand in df.columns:
            if cand != "symbol":
                df = df.rename(columns={cand: "symbol"})
            break
    else:
        raise ValueError("Raw dataframe must contain a symbol column (symbol/ticker/pair/asset).")

    # Types and ordering
    if not np.issubdtype(df["ts"].dtype, np.datetime64):
        df["ts"] = pd.to_datetime(df["ts"], utc=True, errors="coerce")
    df = df.dropna(subset=["ts", "symbol", "close"])
    df = df.sort_values(["symbol", "ts"]).reset_index(drop=True)
    df["symbol"] = df["symbol"].astype(str)
    df["close"] = df["close"].astype("float64")
    return df


def _rolling_beta_alpha(y: pd.Series, x: pd.Series, win: int) -> Tuple[pd.Series, pd.Series]:
    """
    Rolling OLS coefficients between y and x:
      beta_t = Cov(y,x)_t / Var(x)_t
      alpha_t = E[y]_t − beta_t * E[x]_t
    """
    x_mean = x.rolling(win).mean()
    y_mean = y.rolling(win).mean()
    cov = (x * y).rolling(win).mean() - x_mean * y_mean
    var = x.rolling(win).var()
    beta = cov / var.replace(0.0, np.nan)
    alpha = y_mean - beta * x_mean
    return beta, alpha


def _pair_key(a: str, b: str) -> str:
    # Pair key used in filesystem: BTC/USDT__ETH/USDT etc.
    return f"{a.replace('/', '_')}__{b.replace('/', '_')}"


def compute_features_for_pairs(
    raw_df: pd.DataFrame,
    pairs: Iterable[Tuple[str, str]],
    beta_window: int = 300,
    z_window: int = 300,
) -> Dict[str, pd.DataFrame]:
    """
    Build features for each pair using rolling OLS and z-score of spread.

    Inputs:
      raw_df: columns ['ts','symbol','close'] (others ignored)
      pairs: iterable of (a_symbol, b_symbol) like ('BTC/USDT', 'ETH/USDT')
      beta_window: rolling window for OLS coefficients
      z_window: rolling window for z-score of spread

    Output:
      dict: pair_key -> DataFrame with columns:
        ['ts','a_close','b_close','beta','alpha','spread','z']
    """
    if beta_window <= 1 or z_window <= 1:
        raise ValueError("beta_window and z_window must be > 1")

    df = _ensure_schema(raw_df)

    # Make pivot for speed; we keep only 'close' values
    piv = df.pivot(index="ts", columns="symbol", values="close").sort_index()

    out: Dict[str, pd.DataFrame] = {}

    # Iterate pairs; no extra filtering here — screen has already selected cointegrated pairs on 1h.
    for a, b in tqdm(list(pairs), desc="Features(mem)"):
        if a not in piv.columns or b not in piv.columns:
            # Skip if some symbol is missing in 5m data
            continue

        # Align series and drop rows where any of the two is NaN
        px = piv[[a, b]].dropna().sort_index()
        if len(px) < max(beta_window, z_window) + 10:
            # Not enough bars to produce stable features
            continue

        a_close = px[a].astype("float64")
        b_close = px[b].astype("float64")

        # Rolling OLS of y=a on x=b
        beta, alpha = _rolling_beta_alpha(a_close, b_close, int(beta_window))
        spread = a_close - (beta * b_close + alpha)

        # z-score of spread
        mean_sp = spread.rolling(int(z_window)).mean()
        std_sp = spread.rolling(int(z_window)).std()
        z = (spread - mean_sp) / std_sp.replace(0.0, np.nan)

        res = pd.DataFrame(
            {
                "ts": px.index,
                "a_close": a_close,
                "b_close": b_close,
                "beta": beta,
                "alpha": alpha,
                "spread": spread,
                "z": z,
            }
        ).dropna().reset_index(drop=True)

        if len(res) == 0:
            continue

        out[_pair_key(a, b)] = res

    return out
