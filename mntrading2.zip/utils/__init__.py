def minio_io():
    return None