#!/usr/bin/env bash
set -euo pipefail

# -----------------------------------------------------------------------------
# Robust MLflow model serving starter for MNTrading (no 'models download' needed).
# - Waits for MLflow UI to be reachable.
# - Waits for MinIO (S3 endpoint) to be ready.
# - Verifies that requested model+stage exist in MLflow Model Registry.
# - Serves the model directly from "models:/<name>/<stage>" URI.
# -----------------------------------------------------------------------------

MODEL_NAME="${MODEL_NAME:-mntrading_router}"
MODEL_STAGE="${MODEL_STAGE:-Production}"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-5001}"

TRACKING_URI="${MLFLOW_TRACKING_URI:-http://mlflow:5000}"
S3_ENDPOINT="${MLFLOW_S3_ENDPOINT_URL:-}"
AWS_KEY="${AWS_ACCESS_KEY_ID:-}"
AWS_SECRET="${AWS_SECRET_ACCESS_KEY:-}"
AWS_REGION="${AWS_DEFAULT_REGION:-us-east-1}"

log(){ echo "[serve_router] $*"; }

log "ENV:"
log "  MODEL_NAME=${MODEL_NAME}"
log "  MODEL_STAGE=${MODEL_STAGE}"
log "  MLFLOW_TRACKING_URI=${TRACKING_URI}"
log "  MLFLOW_S3_ENDPOINT_URL=${S3_ENDPOINT}"
log "  AWS_ACCESS_KEY_ID=${AWS_KEY:+********}"
log "  AWS_SECRET_ACCESS_KEY=${AWS_SECRET:+********}"
log "  AWS_DEFAULT_REGION=${AWS_REGION}"
log "  HOST=${HOST} PORT=${PORT}"
echo

wait_http_ok() {
  # $1 - url, $2 - max attempts, $3 - sleep seconds
  local url="$1"; local max="${2:-90}"; local nap="${3:-2}"
  for _ in $(seq 1 "$max"); do
    if curl -fsS "$url" >/dev/null 2>&1; then
      return 0
    fi
    sleep "$nap"
  done
  return 1
}

# Wait for MLflow
log "waiting for MLflow UI at ${TRACKING_URI}/ ..."
if ! wait_http_ok "${TRACKING_URI}/" 90 2; then
  log "[FATAL] MLflow UI not reachable"
  exit 1
fi
log "MLflow is reachable"

# Wait for MinIO (if configured)
if [[ -n "${S3_ENDPOINT}" ]]; then
  MINIO_READY_URL="${S3_ENDPOINT%/}/minio/health/ready"
  log "waiting for MinIO at ${MINIO_READY_URL} ..."
  if ! wait_http_ok "${MINIO_READY_URL}" 90 2; then
    log "MinIO readiness endpoint not responding; trying S3 root ${S3_ENDPOINT%/}/ ..."
    if ! wait_http_ok "${S3_ENDPOINT%/}/" 30 2; then
      log "[FATAL] S3 endpoint not reachable: ${S3_ENDPOINT}"
      exit 1
    fi
  fi
  log "S3/MinIO is reachable"
fi

# Verify model exists in registry (Production stage)
log "checking model '${MODEL_NAME}' at stage '${MODEL_STAGE}' ..."
if ! curl -fsS -X POST -H "Content-Type: application/json" \
     -d "{\"name\":\"${MODEL_NAME}\",\"stages\":[\"${MODEL_STAGE}\"]}" \
     "${TRACKING_URI}/api/2.0/mlflow/registered-models/get-latest-versions" \
     | grep -q '"version"'; then
  log "[FATAL] model ${MODEL_NAME}:${MODEL_STAGE} not found in MLflow Model Registry"
  log "Hint: run your pipeline select/promote steps first."
  exit 1
fi
log "model found in registry"

# Serve directly from the registry URI (works with older MLflow CLIs too)
MODEL_URI="models:/${MODEL_NAME}/${MODEL_STAGE}"
log "starting server: mlflow models serve -m ${MODEL_URI} --host ${HOST} --port ${PORT}"
exec mlflow models serve \
  -m "${MODEL_URI}" \
  --host "${HOST}" \
  --port "${PORT}" \
  --env-manager local \
  --workers 1
